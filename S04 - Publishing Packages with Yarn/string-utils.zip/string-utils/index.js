function capitalize(str) {
    if (typeof str !== "string") return "";
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function kebabCase(str) {
    if(typeof str !== "string") return "";
    return str
        .replace(/\s+/g, '-')
        .replace(/([a-z])([A-Z])/g, '$1-$2')
        .toLowerCase();
}

if (module === require.main) {
    console.log(capitalize("hello world"));
    console.log(kebabCase("Hello World"));
}

module.exports = {
    capitalize, kebabCase
};

