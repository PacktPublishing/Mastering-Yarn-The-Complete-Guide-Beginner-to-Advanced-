# string-utils
A simple package to do string manipulation

## Installation
npm install @elsakka/string-utils
or
yarn add @elsakka/string-utils
