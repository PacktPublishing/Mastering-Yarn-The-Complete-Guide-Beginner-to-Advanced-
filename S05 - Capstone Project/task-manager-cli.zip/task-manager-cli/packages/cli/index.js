const { addTask, listTasks, removeTask } = require("core");

//node index.js <command> <arg>
const [,, command, arg] = process.argv;

switch(command) {
    case "add":
        if(!arg) {
            console.log("Please enter a task name.")
        } else {
            addTask(arg);
        }
    break;
    case "list":
        listTasks();
    break;
    case "remove":
        const index = parseInt(arg);
        if(isNaN(index)) {
            console.log("Please provide a correct task number.")
        } else {
            removeTask(index);
        }
    break;
    default:
        console.log("Invalid command.");
}