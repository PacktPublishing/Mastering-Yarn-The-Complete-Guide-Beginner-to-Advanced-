const fs = require("fs");
const path = require("path");

const TASK_FILE = path.join(__dirname, "task.json");

function loadTasks() {
    try {
        const data = fs.readFileSync(TASK_FILE, "utf-8");
        return JSON.parse(data);
    } catch (err) {
        return [];
    }
}

function saveTasks(tasks) {
    fs.writeFileSync(TASK_FILE, JSON.stringify(tasks, null, 2));
}

function addTask(task) {
    const tasks = loadTasks();
    tasks.push(task);
    saveTasks(tasks);
    console.log(`Added task: ${task}`);
}

function listTasks() {
    const tasks = loadTasks();
    if(tasks.length === 0) {
        console.log("No tasks.");
    } else {
        console.log("Tasks: ");
        tasks.forEach((task, index) => {
            console.log(`${index + 1}. ${task}`);
        });
    }
}

function removeTask(index) {
    const tasks = loadTasks();
    if(index <  1 || index > tasks.length) {
        console.log("Invalid task number.");
        return;
    }
    tasks.splice(index - 1, 1);
    saveTasks(tasks);
    console.log("Removed task.");
}

module.exports = {
    addTask,
    listTasks,
    removeTask
};